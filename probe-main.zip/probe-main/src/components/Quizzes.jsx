import React from 'react'

const Quizzes = () => {
  return (
    <>
        <div>
            
        </div>
    </>
  )
}

export default Quizzes
